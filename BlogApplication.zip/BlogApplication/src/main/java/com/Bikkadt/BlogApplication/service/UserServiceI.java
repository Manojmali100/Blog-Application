package com.Bikkadt.BlogApplication.service;

import java.util.List;

import com.Bikkadt.BlogApplication.payloads.UserDto;

public interface UserServiceI {

	UserDto createUser(UserDto user);

	UserDto updateUser(UserDto user, Integer userId);

	UserDto getUserById(Integer userId);

	List<UserDto> getAllUser();

	void deleteUser(Integer UserId);

}
