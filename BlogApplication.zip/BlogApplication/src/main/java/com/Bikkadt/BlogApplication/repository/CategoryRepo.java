package com.Bikkadt.BlogApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Bikkadt.BlogApplication.entity.Category;

@Repository
public interface CategoryRepo extends JpaRepository<Category, Integer> {

}
