package com.Bikkadt.BlogApplication.payloads;

import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter

public class CategoryDto {

	@Id
	private Integer categoryId;
	@NotEmpty
	private String categoryTitel;
	@NotEmpty
	private String categoryDiscription;
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryTitel() {
		return categoryTitel;
	}
	public void setCategoryTitel(String categoryTitel) {
		this.categoryTitel = categoryTitel;
	}
	public String getCategoryDiscription() {
		return categoryDiscription;
	}
	public void setCategoryDiscription(String categoryDiscription) {
		this.categoryDiscription = categoryDiscription;
	}
}
