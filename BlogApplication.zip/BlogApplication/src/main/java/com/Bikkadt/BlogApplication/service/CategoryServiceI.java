package com.Bikkadt.BlogApplication.service;

import java.util.List;

import com.Bikkadt.BlogApplication.payloads.CategoryDto;

public interface CategoryServiceI {

	// Create

	CategoryDto createCategory(CategoryDto categoryDto);

	// Update

	CategoryDto upadteCategory(CategoryDto categoryDto, Integer categoryId);

	// delete

	void deleteCategory(Integer categoryId);

	// get

	CategoryDto getcategory(Integer categoryId);

	// getAll

	List<CategoryDto> getCategories();

}
