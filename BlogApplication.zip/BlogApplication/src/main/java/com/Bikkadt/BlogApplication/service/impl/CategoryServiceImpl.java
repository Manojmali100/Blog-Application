package com.Bikkadt.BlogApplication.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bikkadt.BlogApplication.entity.Category;
import com.Bikkadt.BlogApplication.entity.User;
import com.Bikkadt.BlogApplication.exceptions.ResourceNotFoundException;
import com.Bikkadt.BlogApplication.payloads.CategoryDto;
import com.Bikkadt.BlogApplication.payloads.UserDto;
import com.Bikkadt.BlogApplication.repository.CategoryRepo;
import com.Bikkadt.BlogApplication.service.CategoryServiceI;

@Service
public class CategoryServiceImpl implements CategoryServiceI {
	@Autowired
	private CategoryRepo categoryRepo;
	@Autowired
	private ModelMapper modelMapper;

//	@Override
//	public CategoryDto createCategory(CategoryDto categoryDto) {
//		Category cat = this.modelMapper.map(categoryDto, Category.class);
//		Category addedCat = this.categoryRepo.save(cat);
//		return this.modelMapper.map(addedCat, CategoryDto.class);
//	}
	@Override
	public CategoryDto createCategory(CategoryDto categoryDto) {
	    // Convert DTO to entity
	    Category categoryEntity = this.modelMapper.map(categoryDto, Category.class);

	    // Save entity to the database
	    Category savedCategory = this.categoryRepo.save(categoryEntity);

	    // Convert saved entity back to DTO and return
	    return this.modelMapper.map(savedCategory, CategoryDto.class);
	}


	@Override
	public CategoryDto upadteCategory(CategoryDto categoryDto, Integer categoryId) {
		 Category cat=this.categoryRepo.findById(categoryId)
		.orElseThrow(()->new ResourceNotFoundException("Category", "category id",categoryId));
		cat.setCategoryTitle(categoryDto.getCategoryTitel());
		cat.setCategoryDescription(categoryDto.getCategoryDiscription());
		Category updatedcat = this.categoryRepo.save(cat);
		return this.modelMapper.map(updatedcat, CategoryDto.class);
	}

	@Override
	public void deleteCategory(Integer categoryId) {
		Category cat = this.categoryRepo.findById(categoryId)
		.orElseThrow(()->new ResourceNotFoundException("Category", "category id",categoryId));
		this.categoryRepo.delete(cat);
	}

	@Override
	public CategoryDto getcategory(Integer categoryId) {
		Category cat = this.categoryRepo.findById(categoryId)
				.orElseThrow(()->new ResourceNotFoundException("Category", "category id",categoryId));
		return this.modelMapper.map(cat, CategoryDto.class);
	}

	@Override
	public List<CategoryDto> getCategories() {
		List<Category> categories = this.categoryRepo.findAll();
		List<CategoryDto> catDtos = categories.stream().map((cat)->this.modelMapper.map(cat,CategoryDto.class)).collect(Collectors.toList());
		return catDtos;
	}
//	public Category dtoToUser(CategoryDto CategoryDto) {
//		Category Category = this.modelMapper.map(CategoryDto, Category.class);
//		Category category=new Category();
//		category.setCategoryId(CategoryDto.getCategoryId());
//		category.setCategoryTitle(CategoryDto.getCategoryTitel());
//		category.setCategoryDescription(CategoryDto.getCategoryDiscription());
//		return category;
//	}
//
//	public CategoryDto CategoryTousDto(Category category) {
//   CategoryDto categorydto=this.modelMapper.map(category, CategoryDto.class);
//   categorydto.setCategoryId(category.getCategoryId());
//   categorydto.setCategoryTitel(category.getCategoryTitle());
//   categorydto.setCategoryDiscription(category.getCategoryDescription());
//return categorydto;
//}
}

